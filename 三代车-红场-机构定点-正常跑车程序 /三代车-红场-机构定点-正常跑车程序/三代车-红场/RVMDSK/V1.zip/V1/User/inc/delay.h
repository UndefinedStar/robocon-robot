#ifndef _DELAY_
#define _DELAY_
#include "stm32f4xx.h"
void delay_ms(unsigned int t);
void delay_us(unsigned int t);
#endif
