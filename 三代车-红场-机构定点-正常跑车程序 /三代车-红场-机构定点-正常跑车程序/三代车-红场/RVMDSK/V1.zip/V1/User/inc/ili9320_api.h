#ifndef _ILI9320_API_H
#define _ILI9320_API_H

#include "stm32f4xx.h"

u16 GUI_Color565(u32 RGB);
void GUI_Text(u16 x, u16 y, u8 *str, u16 len,u16 Color, u16 bkColor);
void GUI_Line(u16 x0, u16 y0, u16 x1, u16 y1,u16 color);
void GUI_Circle(u16 cx,u16 cy,u16 r,u16 color,u8 fill);
void GUI_Rectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill);
void  GUI_Square(u16 x0, u16 y0, u16 with, u16 color,u8 fill);

#endif
