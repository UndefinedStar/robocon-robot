#ifndef _LED_SHOW_H
#define _LED_SHOW_H
#include "stdio.h"
#include "ili9320_api.h"
#include "ili9325.h"
void number_show(int x,int y,int a,int n);
void float_number_show(int x,int y,float b);
#endif
